package com.example.mark;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class UserInfo extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private EditText editTextFeet;
    private EditText editTextInches;
    private EditText editTextWeight;
    private Button buttonConfirm;
    double factor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);

        // Gender Spinner.
        Spinner spinner1 = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.Genders, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);
        spinner1.setOnItemSelectedListener(this);

        // Text Entries for Height and Weight.
        editTextFeet = findViewById(R.id.edit_feet);
        editTextInches = findViewById(R.id.edit_inches);
        editTextWeight = findViewById(R.id.edit_weight);
        buttonConfirm = findViewById(R.id.button_confirm);

        editTextInches.addTextChangedListener(loginTextWatcher);
        editTextFeet.addTextChangedListener(loginTextWatcher);
        editTextWeight.addTextChangedListener(loginTextWatcher);

        // Button Clicker.
        buttonConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Records User Input.
                int feet = Integer.parseInt(editTextFeet.getText().toString());
                int inches = Integer.parseInt(editTextInches.getText().toString());
                int weight = Integer.parseInt(editTextWeight.getText().toString());
                // Calculates and prints BMI.
                double bmi = (weight*0.453592)/Math.pow((feet*12+inches)*0.0254, 2);
                double bmiRounded = Math.round(bmi * 10)/10.0;
                String bmiString = Double.toString(bmiRounded);
                TextView bmiText = (TextView) findViewById(R.id.bmi);
                bmiText.setText(bmiString);
                // Calculates and prints the Widmark Factor.
                Spinner spinner = (Spinner) findViewById(R.id.spinner);
                String gender = spinner.getSelectedItem().toString();
                if (gender == "Male") {
                    factor = (1.0181-0.01213*bmiRounded);
                } else {
                    factor = (0.9367-0.01240*bmiRounded);
                }
                String factorString = Double.toString(factor);
                TextView factorText = (TextView) findViewById(R.id.factor);
                factorText.setText(factorString);

                // Clears Text Entries.
                editTextFeet.getText().clear();
                editTextInches.getText().clear();
                editTextWeight.getText().clear();
            }
        });
    }

    private TextWatcher loginTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String Feet = editTextFeet.getText().toString().trim();
            String Inches = editTextInches.getText().toString().trim();
            String Weight = editTextWeight.getText().toString().trim();

            buttonConfirm.setEnabled(!Feet.isEmpty() && !Inches.isEmpty() && !Weight.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
